package com.example.viikko9;

import java.util.ArrayList;
import java.io.Serializable;

public class User implements Serializable {
    private String firstName;
    private String lastName;
    private String email;
    private String degreeProgram;
    private boolean hasBSc;
    private boolean hasMSc;
    private boolean hasLicenciate;
    private boolean hasPhD;



    public User(String firstName, String lastName, String email, String degreeProgram,
                boolean hasBSc, boolean hasMSc, boolean hasLicenciate, boolean hasPhD) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.degreeProgram = degreeProgram;
        this.hasBSc = hasBSc;
        this.hasMSc = hasMSc;
        this.hasLicenciate = hasLicenciate;
        this.hasPhD = hasPhD;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDegreeProgram() {
        return degreeProgram;
    }

    public void setDegreeProgram(String degreeProgram) {
        this.degreeProgram = degreeProgram;
    }
    public boolean hasBSc() {
        return hasBSc;
    }

    public void setBSc(boolean hasBSc) {
        this.hasBSc = hasBSc;
    }

    public boolean hasMSc() {
        return hasMSc;
    }

    public void setMSc(boolean hasMSc) {
        this.hasMSc = hasMSc;
    }

    public boolean hasLicenciate() {
        return hasLicenciate;
    }

    public void setLicenciate(boolean hasLicentiate) {
        this.hasLicenciate = hasLicenciate;
    }

    public boolean hasPhD() {
        return hasPhD;
    }

    public void setPhD(boolean hasPhD) {
        this.hasPhD = hasPhD;
    }
    public String getDegreeLevel() {
        ArrayList<String> degrees = new ArrayList<>();

        if (hasPhD) {
            degrees.add("Doctoral degree");
        }
        if (hasLicenciate) {
            degrees.add("Licenciate");
        }
        if (hasMSc) {
            degrees.add("M.Sc. degree");
        }
        if (hasBSc) {
            degrees.add("B.Sc. degree");
        }

        return String.join(", ", degrees);
    }
}


