package com.example.viikko9;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.TextView;


import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddUserActivity extends AppCompatActivity {

    private EditText editFirstName;
    private EditText editLastName;
    private EditText editEmail;
    private RadioGroup rgDegreeProgram;
    private CheckBox bcCheckBox, msCheckBox, lciCheckBox, phdCheckBox;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_user);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        editFirstName = findViewById(R.id.editFirstName);
        editLastName = findViewById(R.id.editLastName);
        editEmail = findViewById(R.id.editEmail);
        rgDegreeProgram = findViewById(R.id.radioDegreeProgram);

        bcCheckBox = findViewById(R.id.bcCheckBox);
        msCheckBox = findViewById(R.id.msCheckBox);
        lciCheckBox = findViewById(R.id.lciCheckBox);
        phdCheckBox = findViewById(R.id.phdCheckBox);


    }

    public void addUser(View view) {
        String firstName = editFirstName.getText().toString();
        String lastName = editLastName.getText().toString();
        String email = editEmail.getText().toString();

        int checkedId = rgDegreeProgram.getCheckedRadioButtonId();
        String degreeProgram = "";

        if (checkedId == R.id.seRadioButton) {
            degreeProgram = "Software Engineering";
        } else if (checkedId == R.id.imRadioButton) {
            degreeProgram = "Industrial Management";
        } else if (checkedId == R.id.ceRadioButton) {
            degreeProgram = "Computational Engineering";
        } else if (checkedId == R.id.eeRadioButton) {
            degreeProgram = "Electrical Engineering";
        }

        boolean hasBSc = bcCheckBox.isChecked();
        boolean hasMSc = msCheckBox.isChecked();
        boolean hasLicenciate = lciCheckBox.isChecked();
        boolean hasPhD = phdCheckBox.isChecked();


        User newUser = new User(firstName, lastName, email, degreeProgram, hasBSc, hasMSc, hasLicenciate, hasPhD);
        UserStorage.getInstance().addUser(newUser, this);


    }

}







