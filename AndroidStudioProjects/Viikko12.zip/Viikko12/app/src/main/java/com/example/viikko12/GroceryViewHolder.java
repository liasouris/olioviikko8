package com.example.viikko12;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GroceryViewHolder extends RecyclerView.ViewHolder {
    TextView groceryName;

    TextView groceryNote;
    public GroceryViewHolder(@NonNull View itemView) {
        super(itemView);
        groceryName = itemView.findViewById(R.id.textGroceryName);
        groceryNote = itemView.findViewById(R.id.textGroceryNote);

    }
}
