package com.example.viikko12;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import com.example.viikko12.R;
import com.example.viikko12.Grocery;
import com.example.viikko12.ListGrocery;

public class AddGroceryFragment extends Fragment {

    private EditText editGroceryName;
    private EditText editGroceryNote;
    private Button buttonAddGrocery;
    private CheckBox checkImportant;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_grocery, container, false);

        editGroceryName = view.findViewById(R.id.editGroceryName);
        editGroceryNote = view.findViewById(R.id.editGroceryNote);
        buttonAddGrocery = view.findViewById(R.id.buttonAddGrocery);
        checkImportant = view.findViewById(R.id.checkImportant);

        buttonAddGrocery.setOnClickListener(v -> {
            String name = editGroceryName.getText().toString();
            String note = editGroceryNote.getText().toString();
            boolean isImportant = checkImportant.isChecked();

            if (!name.isEmpty()) {
                Grocery newGrocery = new Grocery(name, note, isImportant);
                ListGrocery.getInstance().addGrocery(newGrocery);
                if(getFragmentManager() != null) {
                    getFragmentManager().popBackStack();
                }
            } else {
                System.out.println("No grocery added");
            }
        });

        return view;
    }

}
