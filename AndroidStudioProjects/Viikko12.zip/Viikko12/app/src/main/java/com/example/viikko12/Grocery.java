package com.example.viikko12;

public class Grocery {
    private String name;
    private String note;

    public Grocery(String name, String note, boolean isImportant) {
        this.name = name;
        this.note = note;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    }




