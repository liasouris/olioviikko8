package com.example.viikko12;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.viikko12.GroceryListAdapter;
import com.example.viikko12.ListGrocery;
import com.example.viikko12.R;

public class ListGroceryFragment extends Fragment {

    private RecyclerView rvGroceries;
    private GroceryListAdapter adapter;
    private ListGrocery listGrocery;

    public ListGroceryFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        listGrocery = ListGrocery.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_list_grocery, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvGroceries = view.findViewById(R.id.rvGroceries);
        rvGroceries.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new GroceryListAdapter(getContext(), listGrocery.getGroceries());
        rvGroceries.setAdapter(adapter);
    }
    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.setGroceries(listGrocery.getGroceries());
        }
    }

}
