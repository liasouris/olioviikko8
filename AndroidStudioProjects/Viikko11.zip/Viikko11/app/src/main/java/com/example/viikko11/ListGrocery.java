package com.example.viikko11;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ListGrocery {
    private static ListGrocery instance;
    private final ArrayList<Grocery> groceries;

    private ListGrocery() {
        groceries = new ArrayList<>();
    }

    public static synchronized ListGrocery getInstance() {
        if (instance == null) {
            instance = new ListGrocery();
        }
        return instance;
    }

    public void addGrocery(Grocery grocery) {
        groceries.add(grocery);
    }

    public Grocery getGroceryByName(String name) {
        for (Grocery grocery : groceries) {
            if (grocery.getName().equals(name)) {
                return grocery;
            }
        }
        return null;
    }

    public void removeGrocery(String name) {
        groceries.removeIf(grocery -> grocery.getName().equals(name));
    }

    public ArrayList<Grocery> getGroceries() {
        return groceries;
    }

    public void sortGroceriesByAlphabet() {
        groceries.sort(Comparator.comparing(Grocery::getName));
    }
    public void sortGroceriesByTime() {
        Collections.sort(groceries, new Comparator<Grocery>() {
            @Override
            public int compare(Grocery g1, Grocery g2) {
                return g1.getTimestamp().compareTo(g2.getTimestamp());
            }
        });
    }

}
