package com.example.viikko11;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddGroceryActivity extends AppCompatActivity {
    private EditText editGroceryName;
    private EditText editGroceryNote;
    private Button buttonAddGrocery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_grocery);

        editGroceryName = findViewById(R.id.editGroceryName);
        editGroceryNote = findViewById(R.id.editGroceryNote);
        buttonAddGrocery = findViewById(R.id.buttonAddGrocery);

        buttonAddGrocery.setOnClickListener(view -> {
            String name = editGroceryName.getText().toString();
            String note = editGroceryNote.getText().toString();

            if (!name.isEmpty()) {
                Grocery newGrocery = new Grocery(name, note);
                ListGrocery.getInstance().addGrocery(newGrocery);
                finish();
            } else {
                System.out.print("No grocery added");
            }
        });
    }
}

