package com.example.viikko11;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GroceryViewHolder extends RecyclerView.ViewHolder {
    ImageView removeImage, editImage;
    TextView groceryName, groceryNote;
    EditText editName;
    public GroceryViewHolder(@NonNull View itemView) {
        super(itemView);
        removeImage = itemView.findViewById(R.id.imageDelete);
        editImage = itemView.findViewById(R.id.imageEdit);
        groceryName = itemView.findViewById(R.id.textGroceryName);
        groceryNote = itemView.findViewById(R.id.textGroceryNote);
        editName = itemView.findViewById(R.id.editTextGroceryNote);

    }
}
