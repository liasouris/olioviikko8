package com.example.viikko11;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.viikko11.GroceryListAdapter;


public class MainActivity extends AppCompatActivity {

    private RecyclerView rvGroceries;
    private GroceryListAdapter adapter;
    private ListGrocery listGrocery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listGrocery = ListGrocery.getInstance();

        rvGroceries = findViewById(R.id.rvGroceries);
        rvGroceries.setLayoutManager(new LinearLayoutManager(this));
        adapter = new GroceryListAdapter(this, listGrocery.getGroceries());
        rvGroceries.setAdapter(adapter);

        ImageView imageAlphabet = findViewById(R.id.imageAlphabet);
        imageAlphabet.setOnClickListener(v -> {
            listGrocery.sortGroceriesByAlphabet();
            adapter.notifyDataSetChanged();
        });

        ImageView imageTime = findViewById(R.id.imageTime);
        imageTime.setOnClickListener(v -> {
            listGrocery.sortGroceriesByTime();
            adapter.notifyDataSetChanged();
        });
    }

    public void switchToAddGroceryActivity(View view) {
        Intent intent = new Intent(this, AddGroceryActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.setGroceries(listGrocery.getGroceries());
        adapter.notifyDataSetChanged();
    }
}
